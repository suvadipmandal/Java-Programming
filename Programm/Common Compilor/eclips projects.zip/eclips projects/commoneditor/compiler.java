
public class compiler
{
	public static void main(String args[])
	{
		view_window view=new view_window();
		view.setVisible(true);
	}
}