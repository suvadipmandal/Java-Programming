#include<stdio.h>
#include<conio.h>
#include<windows.h>
void main()
{
system("cls");
printf("Hello world");
getch();
}